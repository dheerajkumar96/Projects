export class Mobiles {
  id: number;
  mobilename: string;
  price: number;
}
