export class Vegetables {
  id: number;
  vegetablename: string;
  priceperkg: number;
}
