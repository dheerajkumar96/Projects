import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tshirts',
  templateUrl: './tshirts.component.html',
  styleUrls: ['./tshirts.component.css']
})
export class TshirtsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
